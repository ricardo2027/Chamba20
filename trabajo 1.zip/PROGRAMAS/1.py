t={1,2,3,5,6,4,2,1,3}
print(len(t))

u=list(t)
a=u.append(1)
print(u)

v=tuple(u)
print(v*2)