L=['Arduino','Protoboard','Programacion']
print(max(L))

S=set(L)
t={'Fisica','Programacion'}
h=S|t
print(h)

T=tuple(L)
x=T[:]
print(x)

