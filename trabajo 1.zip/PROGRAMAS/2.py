a=(1,2,4,'Ricardo',)
print(len(a))

x=set(a)
h=x.add(3)
print(x)

y=list(a)
n=y.remove(2)
print(y)