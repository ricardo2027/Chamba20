s={20,19,20}
print(s)