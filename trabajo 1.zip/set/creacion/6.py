s={'Chamba',2019}
print(s)