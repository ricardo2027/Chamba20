s={17,20}
print(s)