s={7,8,9}
print(s)