s={4,5,6}
print(s)