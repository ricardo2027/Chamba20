s={}
print(s)