s={'Ricardo'}
print(s)