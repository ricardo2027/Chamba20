a={'20','Chamba'}
print(max(a))
