a={'AnA','ANA','ana'}
print(min(a))