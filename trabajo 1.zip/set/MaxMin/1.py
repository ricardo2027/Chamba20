a={1,2,3}
print(max(a))