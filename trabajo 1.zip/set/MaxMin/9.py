a={' @ ',' a ','  A  '}
print(min(a))