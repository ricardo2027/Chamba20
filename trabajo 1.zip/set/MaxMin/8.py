a={'','0'}
print(min(a))