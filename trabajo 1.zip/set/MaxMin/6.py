a={20,19,17,21,10}
print(min(a))