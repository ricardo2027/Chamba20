a={'fisica','Programacion II'}
print(max(a))