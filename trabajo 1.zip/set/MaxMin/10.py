a={1*1,1*2,0**0}
print(min(a))