a={'Arduino','Ricardo'}
print(max(a))