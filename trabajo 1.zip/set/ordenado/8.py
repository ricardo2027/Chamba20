d={10,20,15,30,14,18}
print(set(sorted(d)))