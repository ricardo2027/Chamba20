d={19,21,10,30}
print(set(sorted(d)))