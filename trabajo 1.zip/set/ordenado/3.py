d={'0','1','2'}
print(set(sorted(d)))