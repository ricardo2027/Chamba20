d={1,2,3,6,87,4,2,1,9,10}
print(set(sorted(d)))