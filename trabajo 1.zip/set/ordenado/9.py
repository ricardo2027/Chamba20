d={'EPIE','PROGRAMACION'}
print(set(sorted(d)))