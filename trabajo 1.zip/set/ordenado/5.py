d={'Chamba','17'}
print(set(sorted(d)))