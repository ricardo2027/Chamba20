d={'2','Ricardo','0'}
print(set(sorted(d)))