d={'Ana',''}
print(set(sorted(d)))