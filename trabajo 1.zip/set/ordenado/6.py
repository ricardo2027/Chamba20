d={17,2,20,17}
print(set(sorted(d)))