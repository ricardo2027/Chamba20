s={''}
print(len(s))