s={}
print(len(s))