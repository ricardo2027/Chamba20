s={'',12,20,15,30}
print(len(s))