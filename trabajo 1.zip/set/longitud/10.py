s={'    ',' ',12,'  '}
print(len(s))