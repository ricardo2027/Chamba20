s={60,20,60,30,2}
print(len(s))