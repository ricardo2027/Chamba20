s={1,1,1,1,2,1,5,8}
print(len(s))