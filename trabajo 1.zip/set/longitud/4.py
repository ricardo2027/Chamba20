s={'Ricardo',1,'Ricardo',2,5,3,1,1}
print(len(s))