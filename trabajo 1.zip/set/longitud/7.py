s={12,'','',12,20}
print(len(s))