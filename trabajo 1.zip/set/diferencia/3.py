s={'a','A'}
p={'@','.'}
x=s-p
print(x)