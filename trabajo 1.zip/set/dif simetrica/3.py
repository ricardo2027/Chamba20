s={'a','A'}
p={'@','.','A'}
x=s^p
print(x)