s={20,19,17}
a=s.add(21)
print(s)