s={'Fisica','Analisis'}
a=s.add('Mat.Basica')
print(s)