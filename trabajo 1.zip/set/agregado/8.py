s={19,20,12}
a=s.add(21)
print(s)