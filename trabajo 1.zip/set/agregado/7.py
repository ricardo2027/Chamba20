s={'',' '}
a=s.add('  ')
print(s)