s={1,2,3,4}
a=s.add(4)
print(s)