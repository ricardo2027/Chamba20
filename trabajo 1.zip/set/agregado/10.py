s={1,'1',2,'2'}
a=s.add("2")
print(s)