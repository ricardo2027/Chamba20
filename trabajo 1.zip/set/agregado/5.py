s={'0','1','2'}
a=s.add(2)
print(s)