s={1,2,3}
a=s.add(4)
print(s)