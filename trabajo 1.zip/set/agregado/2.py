s={'Ricardo'}
a=s.add('Chamba')
print(s)