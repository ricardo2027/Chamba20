k={2,15,1,23,1,5,2,1,31}
a=k.remove(15)
print(k)