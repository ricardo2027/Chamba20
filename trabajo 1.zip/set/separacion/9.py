k={0,13,39,12}
a=k.remove(12)
print(k)