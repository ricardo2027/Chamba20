k={'FISICA',' ',''}
a=k.remove(' ')
print(k)