k={'MANZANA','PROGRAMACION','EPIE'}
a=k.remove('MANZANA')
print(k)