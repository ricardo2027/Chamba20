k={'fisica','','FISICA'}
a=k.remove('FISICA')
print(k)