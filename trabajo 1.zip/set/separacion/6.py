k={1,3,5,7}
a=k.remove(7)
print(k)