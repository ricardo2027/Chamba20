k={'0',1,1,'1'}
a=k.remove(1)
print(k)