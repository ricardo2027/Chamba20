k={0,1,2,3}
a=k.remove(1)
print(k)