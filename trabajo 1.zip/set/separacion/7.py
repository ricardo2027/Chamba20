k={'0','2','4','6'}
a=k.remove('0')
print(k)