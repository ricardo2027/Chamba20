k={0,0,1,2,1,5,6}
a=k.remove(0)
print(k)