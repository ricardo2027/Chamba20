k={'Ricardo','EPIE'}
l=k.copy()
print(l)