k={1,2,'1','2'}
l=k.copy()
print(l)