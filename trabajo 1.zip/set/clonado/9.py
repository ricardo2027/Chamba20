k={1,2,3,1,2}
l=k.copy()
print(l)