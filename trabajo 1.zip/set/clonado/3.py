k={'20',12,'2019'}
l=k.copy()
print(l)