k={'Electronica',20}
l=k.copy()
print(l)