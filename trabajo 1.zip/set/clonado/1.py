k={1,2,3}
l=k.copy()
print(l)