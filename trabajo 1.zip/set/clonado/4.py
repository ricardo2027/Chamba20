k={12,20,19}
l=k.copy()
print(l)