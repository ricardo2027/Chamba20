k={'Copy','Paste'}
l=k.copy()
print(l)