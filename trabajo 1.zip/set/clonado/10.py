k={ }
l=k.copy()
print(l)