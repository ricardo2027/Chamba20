k={12,30,'30'}
l=k.copy()
print(l)