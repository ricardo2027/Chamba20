k={'EPIE','UNPRG',23}
a=k.discard(23)
print(k)