k={'Analisis','Manzana','Fisica'}
a=k.discard('Manzana')
print(k)