k={0,1,2,13,21,48,1,0,1}
a=k.discard(0)
print(k)