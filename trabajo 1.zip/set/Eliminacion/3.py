k={'Universidad','No','Licenciada'}
a=k.discard('No')
print(k)