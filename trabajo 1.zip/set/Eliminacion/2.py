k={'Ricardo','20',12}
a=k.discard(12)
print(k)