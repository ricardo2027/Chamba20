k={20,17,19,21}
a=k.discard(17)
print(k)