k={'Ricardo',0,1,2}
a=k.discard(0)
print(k)