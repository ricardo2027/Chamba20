k={'1','2',' '}
a=k.discard(' ')
print(k)