k={0,'Programacion II'}
a=k.discard(0)
print(k)