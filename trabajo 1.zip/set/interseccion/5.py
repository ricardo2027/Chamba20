s={'EPIE','¿?'}
p={0,'PROGRAMACION','¿?'}
x=s&p
print(x)