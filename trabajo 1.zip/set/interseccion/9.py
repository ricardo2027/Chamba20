s={1,2,3}
p={1,2,3,4}
x=p&s
print(x)