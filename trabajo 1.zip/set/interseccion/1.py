s={1,2,3}
p={0}
x=s&p
print(x)