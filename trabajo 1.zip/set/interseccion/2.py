s={'Ricardo',20}
p={'Chamba','Jimenez','20'}
x=s&p
print(x)