s={'29','12'}
p={'17'}
x=s&p
print(x)