s={3,4,5,6}
p={1,2,5}
x=s&p
print(x)