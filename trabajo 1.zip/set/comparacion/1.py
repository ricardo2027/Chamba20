s={}
t={''}
print(s==t)