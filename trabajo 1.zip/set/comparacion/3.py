s={'ana','Ana'}
t={'Ana','ana'}
print(s>=t)