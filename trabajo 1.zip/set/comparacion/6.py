s={1,2,3}
t={15}
print(s==t)