s={'Apple'}
t={'PC'}
print(s>t)