s={'CHILE'}
t={'PERU'}
print(t>=s)