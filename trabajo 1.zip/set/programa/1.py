#longitud
s={0,1,2,9}
print(len(s))

#MaxMin
print(max(s))

#Agregado
t=s.add(7)
print(s)

#Union
u={0,1,2,3,4,5,6,8}
print(s|u)

#Dif Simetrica
print(s^u)