k={'Ricardo',30}
a=k.pop()
print(a)
print(k)