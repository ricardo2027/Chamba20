k={12,'Chamba','Ricardo'}
a=k.pop()
print(a)
print(k)