k={'',' ','  '}
a=k.pop()
print(a)
print(k)