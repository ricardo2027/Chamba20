P={1,2,3,4}
L=P.pop()
print(L)
print(P)