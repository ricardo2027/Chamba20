k={1,1,2,3,'EPIE'}
a=k.pop()
print(a)
print(k)