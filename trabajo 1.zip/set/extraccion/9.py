k={'Manzana','Fisica','EPIE'}
a=k.pop()
print(a)
print(k)