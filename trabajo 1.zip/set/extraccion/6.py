k={'Fisica','0','1','2'}
a=k.pop()
print(a)
print(k)