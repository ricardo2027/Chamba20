k={12,4,60}
a=k.pop()
print(a)
print(k)