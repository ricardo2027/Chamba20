k={'Ricardo','Chamba'}
a=k.pop()
print(a)
print(k)