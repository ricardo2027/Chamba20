s={'12',12,'20'}
k=s.clear()
print(s)