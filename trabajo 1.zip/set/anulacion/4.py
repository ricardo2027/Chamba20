s={ }
k=s.clear()
print(s)