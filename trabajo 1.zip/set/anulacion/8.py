s={21,10,19,5,43}
k=s.clear()
print(s)