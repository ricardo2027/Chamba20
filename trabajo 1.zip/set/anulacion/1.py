s={1,2,3}
k=s.clear()
print(s)