s={19,18,20}
k=s.clear()
print(s)