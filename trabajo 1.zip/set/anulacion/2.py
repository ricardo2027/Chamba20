s={1,2,'Ricardo'}
k=s.clear()
print(s)