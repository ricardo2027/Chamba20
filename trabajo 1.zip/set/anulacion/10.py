s={'Electronica','EPIE'}
k=s.clear()
print(s)