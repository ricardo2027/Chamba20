s={'Programacion','Fisica'}
k=s.clear()
print(s)