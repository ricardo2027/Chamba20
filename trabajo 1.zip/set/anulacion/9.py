s={'Chamba','UNPRG'}

k=s.clear()
print(s)