s={17,19,20,12,21,10}
for a in s:
    print(a)