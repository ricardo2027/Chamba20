s={12,36,32,5}
for a in s:
    print(a)