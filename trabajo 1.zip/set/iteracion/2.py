s={1,2,'Ricardo',1,2,4,5,1}
for a in s:
    print(a)