s={19,20,50}
for a in s:
    print(a)