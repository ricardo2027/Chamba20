s={17,'Ricardo',20}
for a in s:
    print(a)