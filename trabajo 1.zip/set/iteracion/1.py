s={1,2,3}
for a in s:
    print(a)