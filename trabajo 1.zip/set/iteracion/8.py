s={0,2,4,6,8}
for a in s:
    print(a)