s={ }
for a in s:
    print(a)