s={'Arduino','EPIE'}
for a in s:
    print(a)