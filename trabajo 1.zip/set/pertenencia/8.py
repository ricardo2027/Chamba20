x={'Ana','Ricardo'}
if 'ana'not in x:
    print(True)
else:
    print(False)