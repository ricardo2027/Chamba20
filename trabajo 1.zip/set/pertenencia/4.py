x={20,17,10,20,20+7,17,10}
if 27 in x:
    print(True)
else:
    print(False)