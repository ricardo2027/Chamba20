x={12,34,56}
if 5 not in x:
    print(True)
else:
    print(False)