x={'Ana','ana','Beatriz','beatriz'}
if 'beatriz' in x:
    print(True)
else:
    print(False)