x={'Ricardo',20,17}
if 'Ric' in x:
    print(True)
else:
    print(False)