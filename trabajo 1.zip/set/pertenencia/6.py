x={}
if 5 in x:
    print(True)
else:
    print(False)