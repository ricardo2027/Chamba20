x={'Ricardo','Chamba',17}
if 18 in x:
    print(True)
else:
    print(False)