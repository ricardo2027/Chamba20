x={'',' ','   '}
if '    ' in x:
    print(True)
else:
    print(False)