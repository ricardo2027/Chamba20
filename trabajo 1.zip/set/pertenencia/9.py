x={4**5}
if 64*16 in x:
    print(True)
else:
    print(False)