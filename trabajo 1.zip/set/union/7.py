s={1,2,' '}
p={'',21}
x=s.union(p)
print(x)