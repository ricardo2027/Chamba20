s={1,2,3}
p={3,8,9,6,42,8}
x=s.union(p)
print(x)