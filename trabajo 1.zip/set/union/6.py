s={1,2,0}
p={0,12,3,5,1}
x=s.union(p)
print(x)