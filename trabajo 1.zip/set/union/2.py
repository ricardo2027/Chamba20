s={'Ricardo',20}
p={'Chamba','Jimenez'}
x=s|p
print(x)