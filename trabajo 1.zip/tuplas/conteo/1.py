t=(1,2,3,)
a=t.count(1)
print(a)