t=('',1,4,2,3,6,4,2)
a=t.count(4)
print(a)