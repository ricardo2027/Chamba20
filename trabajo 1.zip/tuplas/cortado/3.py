t1=('Ricardo',17,)
a=t1[0:1:1]
print(a)