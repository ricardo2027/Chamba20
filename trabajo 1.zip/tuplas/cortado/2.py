t1=('Chamba',20,17,)
a=t1[0:1:1]
print(a)