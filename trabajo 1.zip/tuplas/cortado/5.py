t1=('Placa','Resistor',6,)
a=t1[0:1:2]
print(a)