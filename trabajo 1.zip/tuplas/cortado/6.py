t1=('Manzana',4,20,)
a=t1[0:1:3]
print(a)