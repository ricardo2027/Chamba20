t1=('Arduino',1,6,)
a=t1[1:3:1]
print(a)