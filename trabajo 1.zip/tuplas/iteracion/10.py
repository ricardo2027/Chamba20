t1=('Ingenieria','Placo',17,)
for l in t1:
    print(l)