t1=(1,3,'Ricardo',)
for l in t1:
    print(l)