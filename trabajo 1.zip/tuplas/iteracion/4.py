t1=(17,'',20,)
for l in t1:
    print(l)