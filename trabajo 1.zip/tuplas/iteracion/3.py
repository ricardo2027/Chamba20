t1=(1,'Programacion','2 ')
for l in t1:
    print(l)