t1=(20,'Chamba',17,)
for l in t1:
    print(l)