t=('Ricardo',15,20,)
z=t[:]
print(t)