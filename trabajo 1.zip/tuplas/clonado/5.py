t=('Chamba',20,17,)
s=t[:]
print(t)