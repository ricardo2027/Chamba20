t=(17,'Programacion',)
h=t[:]
print(t)