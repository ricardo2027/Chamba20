t=(1,2,4,6,)
v=t[:]
print(t)