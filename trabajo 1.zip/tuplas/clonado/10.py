t=('Fisica',20,)
k=t[:]
print(t)