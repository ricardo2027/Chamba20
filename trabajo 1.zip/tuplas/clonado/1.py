t=(1,2,)
x=t[:]
print(x)