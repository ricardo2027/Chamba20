t=('',)
p=t[:]
print(t)