t=(1,2,3,5,8,)
w=t[:]
print(t)