r1=(1,'Chamba',)
a=r1.index('Chamba')
print(a)