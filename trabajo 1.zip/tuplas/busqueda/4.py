r1=(1,3,5,7,9)
a=r1.index(7)
print(a)