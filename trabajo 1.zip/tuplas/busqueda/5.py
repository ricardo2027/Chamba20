r1=(1,2,'Arduino')
a=r1.index(2)
print(a)