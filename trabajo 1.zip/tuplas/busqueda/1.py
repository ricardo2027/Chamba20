r1=(1,2,3,)
a=r1.index(1)
print(a)