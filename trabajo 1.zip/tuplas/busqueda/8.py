r1=(1,'Placa',)
a=r1.index(1)
print(a)