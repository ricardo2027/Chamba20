r1=(1,'Ricardo',)
a=r1.index("Ricardo")
print(a)