r1=(2,4,6,8,)
a=r1.index(8)
print(a)