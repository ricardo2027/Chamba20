r1=(10,15,20,25,30,)
a=r1.index(30)
print(a)