r1=('Fisica','15',20,)
a=r1.index('15')
print(a)