r1=(1,2,'Programacion')
a=r1.index('Programacion')
print(a)