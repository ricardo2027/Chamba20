h=1,'Arduino'
print(h)