r=(1,"Ricardo",)
print(r)