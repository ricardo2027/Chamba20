f=("Java",12)
print(f)