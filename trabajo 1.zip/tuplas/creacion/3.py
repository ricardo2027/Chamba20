s=(3,5,)
print(s)