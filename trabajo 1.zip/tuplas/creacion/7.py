g=20,17,'Ricardo'
print(g)