t=()
print(t)