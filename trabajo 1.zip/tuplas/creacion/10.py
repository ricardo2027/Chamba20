w=("FOX",29)
print(w)