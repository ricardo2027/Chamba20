s=1,2,3,'a'
print(s)