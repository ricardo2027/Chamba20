r=(12,)
print(r)