a=(1,2,)
c=(4,4,)
print(a+c)