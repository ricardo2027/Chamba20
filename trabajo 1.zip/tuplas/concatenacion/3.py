s=(3,5,)
t=(1,2,)
u=t+s
print(u)