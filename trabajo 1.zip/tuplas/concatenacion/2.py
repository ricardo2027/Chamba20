r=(12,)
s=(12,42,)
print(r+s)