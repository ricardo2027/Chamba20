s=1,2,3,'a'
t='b',6,
print(t+s)