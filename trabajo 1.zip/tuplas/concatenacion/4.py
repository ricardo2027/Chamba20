h=(1,2,3,)
j=(4,5,)
k=j+h
print(k)