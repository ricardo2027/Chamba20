r=(1,"Ricardo",)
s=('Chamba',20)
print(r+s)