f=(17,20,)
h=(18,"Chamba")
print(f+h)