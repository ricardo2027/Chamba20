g=20,17,'Ricardo'
l='Martin',19,
print(g+l)