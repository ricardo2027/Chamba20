t=(1,)
s=(12,)
print(t+s)