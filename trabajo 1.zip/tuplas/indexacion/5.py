t1=(4,6,78,)
a=t1[2]
print(a)