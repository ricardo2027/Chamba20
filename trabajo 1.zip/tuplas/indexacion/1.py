t1=(1,2,)
a=t1[1]
print(a)