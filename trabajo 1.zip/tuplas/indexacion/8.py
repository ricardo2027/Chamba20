t1=('Fox',2,)
a=t1[0]
print(a)