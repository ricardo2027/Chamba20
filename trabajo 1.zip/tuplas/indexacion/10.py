t1=('Ricardo','20/17',)
a=t1[1]
print(a)