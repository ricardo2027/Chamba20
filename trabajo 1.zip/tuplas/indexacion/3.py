t1=(17,20,'Chamba')
a=t1[2]
print(a)
