t1=('',1,)
a=t1[0]
print(a)