t1=(1,'RicFat',)
a=t1[1]
print(a)