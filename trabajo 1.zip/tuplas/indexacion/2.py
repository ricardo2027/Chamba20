t1=(1,'Ricardo',)
a=t1[0]
print(a)