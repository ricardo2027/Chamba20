t1=('Arduino',2,)
a=t1[0]
print(a)