t1=(1,3,)
t2=(2,4,)
a=t1<t2
print(a)