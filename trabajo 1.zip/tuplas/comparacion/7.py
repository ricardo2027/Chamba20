t1=('Ricardo',12)
t2=('Fati',4,)
a=t1<t2
print(a)