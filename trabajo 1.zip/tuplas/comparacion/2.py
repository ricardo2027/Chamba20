t1=('Ricardo',17,)
t2=('Chamba',20,)
a=t1>=t2
print(a)