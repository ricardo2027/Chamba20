t1=(20,19,)
t2=(17,)
a=t1<=t2
print(a)