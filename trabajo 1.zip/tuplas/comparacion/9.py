t1=(1,'Arduino',)
t2=(2,'Fox',)
a=(t1==t2)
print(a)