t1=('luis',1,)
t2=('Luis',1,)
a=(t1==t2)
print(a)