t1=('Manzana',1,)
t2=('Uva',2,)
a=(t1==t2)
print(a)