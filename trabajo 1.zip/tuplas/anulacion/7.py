t=('',)
t=()
print(t)