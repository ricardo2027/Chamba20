t=(1,2,)
t=()
print(t)