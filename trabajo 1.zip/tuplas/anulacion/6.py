t=(1,2,4,6,)
t=()
print(t)