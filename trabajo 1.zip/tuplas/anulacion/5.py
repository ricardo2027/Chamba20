t=('Chamba',20,17,)
t=()
print(t)