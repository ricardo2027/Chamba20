t=(1,'Programacion',)
t=()
print(t)