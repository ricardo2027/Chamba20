t=('Fisica',20,)
t=()
print(t)