t=('Ricardo',15,20,)
t=()
print(t)