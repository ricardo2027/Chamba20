x=["lista","set","tuplas"]
x*=4
print(x)