r=["Arduino","Raspberry","Pc"]
r*=4
print(r)