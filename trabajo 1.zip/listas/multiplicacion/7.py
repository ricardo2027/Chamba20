p=["Rojo","Negro","Amarillo"]
p*=2
print(p)