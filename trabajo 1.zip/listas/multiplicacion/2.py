a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a*=2
print(a)