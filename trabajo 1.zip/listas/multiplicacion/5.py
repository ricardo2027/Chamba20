d=["Prpgramacion","Fisica","Calculo"]
d*=5
print(d)