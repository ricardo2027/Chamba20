x=["Ricardo","Chamba",20]
x*=2
print(x)