m=["Samsung","Apple","Huawei"]
m*=3
print(m)
