a=[12,15,11]
a*=4
print(a)