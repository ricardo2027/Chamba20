d=["Pera","Fisca","Pesca"]
print(d[::3])