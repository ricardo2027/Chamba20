c=["Ricardo","","17"]
print(c[1::-1])