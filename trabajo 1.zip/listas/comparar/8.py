x=[10,"15"]
y=[9]
z=x<y
print(z)