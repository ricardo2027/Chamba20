x=["Ricardo"]
y=["Chamba"]
z=(x<y)
print(z)