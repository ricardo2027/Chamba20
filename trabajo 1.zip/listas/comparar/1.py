a=["Universidad"]
b=["Pedro"]
c=a<=b
print(c)