a=["Manzana"]
b=["Pera"]
c=a>b
print(c)