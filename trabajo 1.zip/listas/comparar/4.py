x=[""]
y=["0"]
z=x<y
print(z)