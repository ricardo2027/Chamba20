x=[15,12]
y=[12,15]
z=x>y
print(z)