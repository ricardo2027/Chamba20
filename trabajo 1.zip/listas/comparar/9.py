r=[12,19]
s=[20]
z=r>s
print(z)