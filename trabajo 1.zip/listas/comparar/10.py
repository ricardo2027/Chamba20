p=["13"]
q=["12"]
r=p<q
print(r)