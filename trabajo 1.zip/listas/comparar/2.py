x=["15"]
y=["15"]
z=(x==y)
print(z)