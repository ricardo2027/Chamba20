a=[12]
b=[15]
c=a<b
print(c)