nota1=12
nota2=15
x=[nota1,nota2]

nota3=13
nota4=10
y=[nota3,nota4]

print(x+y)