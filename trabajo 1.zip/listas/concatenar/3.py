edad1=21
edad2=18
x=[edad1,edad2]

edad3=16
edad4=17
y=[edad3,edad4]

print(x+y)