x="Netflix"
y="Disney"
z=[x,y]

a="Marvel"
b="Fox"
c=[a,b]

print(z+c)