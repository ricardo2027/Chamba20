curso1="Programacion II"
curso2="Analisis Matematico"
x=[curso1,curso2]

curso3="Matematica Basica"
curso4="Fisica"
y=[curso3,curso4]

print(x+y)