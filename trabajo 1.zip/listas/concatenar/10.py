colegio1="Appul College"
colegio2="Cima"
x=[colegio1,colegio2]

colegio3="Jorge Basadre"
colegio4="Peruano Español"
y=[colegio3,colegio4]

print(x+y)