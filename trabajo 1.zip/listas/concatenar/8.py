nombre_1=input("Ingrese nombre 1:")
nombre_2=input("Ingrese nombre 2:")
x=[nombre_1,nombre_2]

Nro_DNI=int(input("Ingrese Nro del DNI: "))
Sexo=input("Ingrese su sexo: ")
y=[Nro_DNI,Sexo]

print(x+y)