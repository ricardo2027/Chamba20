A1=1
A2=1
x=[A1,A2]

A3=2
A4=3
y=[A3,A4]

print(x+y)