fruta1="Granadilla"
fruta2="Uva"
x=[fruta1,fruta2]

fruta3="Naranja"
fruta4="Manzana"
y=[fruta3,fruta4]

print(x+y)