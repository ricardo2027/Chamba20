genero1="Rock"
genero2="Heavy metal"
x=[genero1,genero2]

genero3="Trap"
genero4="Cumbia"
y=[genero3,genero4]

print(x+y)