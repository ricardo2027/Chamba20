nombre_1=input("Ingrese nombre 1:")
nombre_2=input("Ingrese nombre 2:")
x=[nombre_1,nombre_2]

apellido_1=input("Ingrese primer apellido: ")
apellido_2=input("Ingrese segundo apellido: ")
y=[apellido_1,apellido_2]

print(x+y)