p=["Rojo","Negro","Amarillo"]
del p[0]
print(p)