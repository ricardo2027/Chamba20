c=["Ricardo",20,"17"]
del c[2]
print(c)