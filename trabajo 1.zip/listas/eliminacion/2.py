curso1="Programacion II"
curso2="Analisis II"
a=[curso1,curso2]
del a[1]
print(a)