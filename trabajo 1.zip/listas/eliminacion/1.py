nota1=11
nota2=20
a=[nota1,nota2]
del a[:]
print(a)