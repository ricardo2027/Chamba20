d=["Prpgramacion","Fisica","Calculo"]
del d[2]
print(d)