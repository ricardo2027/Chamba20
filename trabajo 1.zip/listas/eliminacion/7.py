x=["Arduino","Raspberry","Pc"]
del x[2]
print(x)