a=[12,1,2]
del a[0:1]
print(a)