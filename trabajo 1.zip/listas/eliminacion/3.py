fruta1="Manzana"
fruta2="Uva"
a=[fruta1,fruta2]
del a[0:1:-1]
print(a)