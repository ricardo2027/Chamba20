x=["lista","set","tuplas"]
del x[1]
print(x)