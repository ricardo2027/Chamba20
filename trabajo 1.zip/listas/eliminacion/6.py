m=["Samsung","Apple","Huawei"]
del m[:]
print(m)
