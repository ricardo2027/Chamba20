r=["Arduino","Raspberry","Pc"]
r.reverse()
print(r)