y=["Manzana","Mandarina","Pera"]
y.reverse()
print(y)