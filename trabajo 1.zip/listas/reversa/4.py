x=["Ricardo","Chamba",20]
x.reverse()
print(x)