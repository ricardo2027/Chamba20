a=[12,15,11]
a.reverse()
print(a)