p=["Rojo","Negro","Amarillo"]
p.reverse()
print(p)