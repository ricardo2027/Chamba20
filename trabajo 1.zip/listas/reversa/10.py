m=["Samsung","Apple","Huawei"]
m.reverse()
print(m)