n=["10","15","16"]
n.reverse()
print(n)