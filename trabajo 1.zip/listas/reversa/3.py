a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a.reverse()
print(a)