x=["lista","set","tuplas"]
x.reverse()
print(x)