d=["Prpgramacion","Fisica","Calculo"]
d.reverse()
print(d)