curso1="Programacion II"
curso2="Analisis II"
a=[curso1,curso2,curso1]
print(a.count(curso2))