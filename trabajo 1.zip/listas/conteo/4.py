nota1="10"
nota2="15"
a=[nota1,nota2,nota2,nota2]

print(a.count(nota2))