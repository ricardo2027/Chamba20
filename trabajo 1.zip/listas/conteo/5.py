nombre1=input("Ingrese su nombre")
nro_dni=int(input("Ingrese su nro de DNI: "))
x=[nombre1,nro_dni,nro_dni]
print(x.count(nro_dni))