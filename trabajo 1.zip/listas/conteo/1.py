a=[12,11,10,10]
print(a.count(10))