d=[12,"PG2","Yoshi"]
print(d.count("Yoshi"))