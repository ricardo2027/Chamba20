a=[12,1,2,12,3,5,12]
print(a.count(12))