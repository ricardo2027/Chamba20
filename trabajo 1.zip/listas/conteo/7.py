c=["Ricardo","","17",""]
print(c.count(""))