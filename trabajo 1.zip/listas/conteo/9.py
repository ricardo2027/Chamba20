c="15"
d="29"
e=[c,d+c,c,d,c,d]
print(e.count(d))