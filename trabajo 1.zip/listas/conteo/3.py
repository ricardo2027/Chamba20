fruta1="Manzana"
fruta2="Uva"
a=[fruta1,fruta2,fruta2]
print(a.count(fruta2))