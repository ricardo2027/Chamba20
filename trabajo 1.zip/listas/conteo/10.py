d=["Pera","Fisica","Pesca","Fisica"]
print(d.count(d[1]))