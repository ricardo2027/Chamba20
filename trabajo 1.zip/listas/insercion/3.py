a=["Universidad","Pedro Ruiz Gallo"]
b="Licenciada"
a.insert(2,b)
print(a)