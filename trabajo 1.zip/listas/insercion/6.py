d=["Prpgramacion","Fisica","Calculo"]
e="Analisis"
d.insert(3,e)
print(d)