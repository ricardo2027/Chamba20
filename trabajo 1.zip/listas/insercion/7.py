n=["10","15","16"]
m=12
n.insert(1,m)
print(n)