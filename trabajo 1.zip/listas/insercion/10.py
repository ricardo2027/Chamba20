r=["Arduino","Raspberry","Pc"]
s="Android"
r.insert(2,s)
print(r)