x=["Ricardo","Chamba"]
y=20
x.insert(1,y)
print(x)