p=["Rojo","Negro","Amarillo"]
v="Blanco"
p.insert(1,v)
print(p)