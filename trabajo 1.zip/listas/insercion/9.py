x=["lista","set","tuplas"]
y="if"
x.insert(2,y)
print(x)