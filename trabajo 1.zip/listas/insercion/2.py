s=[12,14]
f=[11,10]
s.insert(0,f)
print(s)