s=[12,14]
s.insert(0,20)
print(s)