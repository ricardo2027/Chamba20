fruta1="Manzana"
fruta2="Uva"
a=[fruta1,fruta2]
a.append("Pera")
print(a)