a=[12,15,11]
a.append(16)
print(a)