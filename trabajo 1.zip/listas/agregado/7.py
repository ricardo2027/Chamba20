p=["Rojo","Negro","Amarillo"]
p.append("Blanco")
print(p)