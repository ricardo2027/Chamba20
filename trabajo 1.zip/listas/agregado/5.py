d=["Prpgramacion","Fisica","Calculo"]
d.append("Matematicas")
print(d)