x=["lista","set","tuplas"]
x.append("if")
print(x)