r=["Arduino","Raspberry","Pc"]
r.append("Android")
print(r)