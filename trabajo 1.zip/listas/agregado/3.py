x=["Ricardo","Chamba",20]
x.append(17)
print(x)