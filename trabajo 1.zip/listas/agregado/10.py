m=["Samsung","Apple","Huawei"]
m.append("MIU")
print(m)
