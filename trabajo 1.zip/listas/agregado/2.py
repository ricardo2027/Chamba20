a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a.append("Al fin")
print(a)