n=["10","15","16"]
n.append(20)
print(n)