s=[]
print(len(s))