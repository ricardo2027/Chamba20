a=12
b=14
c=16
x=[a,b,c]
print(len(x))