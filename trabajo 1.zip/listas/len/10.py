x="1"+"7"
y="Ricardo"
z=[x,y]
print(len(z))