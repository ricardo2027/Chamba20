a="Hello"
b="World"
c=[a+b,a]
print(len(c))