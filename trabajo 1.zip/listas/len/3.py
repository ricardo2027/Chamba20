x="Manzana"
y="Naranja"
z="Fresa"
a=[x,z,y]
print(len(a))