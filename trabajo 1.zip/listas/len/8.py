a="Ricardo"
d=[a,a]
print(len(d))
