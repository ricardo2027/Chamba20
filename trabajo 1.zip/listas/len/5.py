r="Arduino"
s="Protoboard"
v=[r,s]
print(len(v))