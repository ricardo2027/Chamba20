notas = [10,15,20]
# Agregado
X = int(input("Ingrese la cuarta nota:"))
notas.append(X)
print(notas)

# Remove
y = int(input("Que nota desea eliminar?:"))
notas.remove(y)
print(notas)

# Ordenado
z= notas.sort()
print(notas)

# Reversa
a= notas.reverse()
print(notas)

# Extraccion
y=notas.pop(0)
print(y)
print(notas)