d=["Prpgramacion","Fisica","Calculo"]
d.sort()
print(d)