m=["Samsung","Apple","Huawei"]
m.sort()
print(m)