x=["lista","set","tuplas"]
x.sort()
print(x)