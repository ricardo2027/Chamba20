a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a.sort()
print(a)