s=[1,2,5,6,3,4]
s.sort()
print(s)