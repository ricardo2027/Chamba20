n=["10","15","16"]
n.sort()
print(n)