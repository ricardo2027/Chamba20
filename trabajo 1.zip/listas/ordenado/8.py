x=["Ricardo","Chamba","20"]
x.sort()
print(x)