p=["Rojo","Negro","Amarillo"]
p.sort()
print(p)