y=["Manzana","Mandarina","Pera"]
y.sort()
print(y)