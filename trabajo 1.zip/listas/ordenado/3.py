r=["Arduino","Raspberry","Pc"]
r.sort()
print(r)