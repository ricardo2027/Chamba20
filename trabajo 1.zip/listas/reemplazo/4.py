x=["lista","set","tuplas"]
x[2]="for"
print(x)