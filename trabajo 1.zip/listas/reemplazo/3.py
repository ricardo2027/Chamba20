r=["Arduino","Raspberry","Pc"]
r[2]="Android"
print(r)