p=["Rojo","Negro","Amarillo"]
p[2]="Azul"
print(p)