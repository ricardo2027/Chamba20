y=["DNI","PASAPORTE"]
y[1]="BREVETE"
print(y)