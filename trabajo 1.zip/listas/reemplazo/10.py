w=["FOX","Disney","TNT"]
w[2]="Marvel"
print(w)