m=["Samsung","Apple","Huawei"]
m[2]="MIU"
print(m)
