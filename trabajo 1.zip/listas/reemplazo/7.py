d=["Prpgramacion","Fisica","Calculo"]
d[1]="Matematica"
print(d)