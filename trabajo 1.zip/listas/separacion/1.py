a=[12,15,11]
a.remove(12)
print(a)