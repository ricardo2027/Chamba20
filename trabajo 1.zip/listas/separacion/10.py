m=["Samsung","Apple","Huawei"]
m.remove(m[2])
print(m)
