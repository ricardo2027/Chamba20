x=["Ricardo","Chamba",20]
x.remove(20)
print(x)