p=["Rojo","Negro","Amarillo"]
p.remove(p[1])
print(p)