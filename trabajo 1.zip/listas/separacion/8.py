x=["lista","set","tuplas"]
x.remove(x[2])
print(x)