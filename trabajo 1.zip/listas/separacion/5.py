d=["Prpgramacion","Fisica","Calculo"]
d.remove(d[2])
print(d)