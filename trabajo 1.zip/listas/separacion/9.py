r=["Arduino","Raspberry","Pc"]
r.remove(r[2])
print(r)