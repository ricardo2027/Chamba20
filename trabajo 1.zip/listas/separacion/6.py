n=["10","15","16"]
n.remove(n[2])
print(n)