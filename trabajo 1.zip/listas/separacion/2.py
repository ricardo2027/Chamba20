y=["Manzana","Mandarina","Pera"]
y.remove(y[1])
print(y)