a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a.remove(a[0])
print(a)