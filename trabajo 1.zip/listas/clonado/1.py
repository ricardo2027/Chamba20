a=[12,15,11]
x=a.copy()
del a[:]
print(a)
print(x)