r=["Arduino","Raspberry","Pc"]
n=r.copy()
del r[2]
print(r)
print(n)