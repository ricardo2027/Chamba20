m=["Samsung","Apple","Huawei"]
n=m.copy()
del m[2]
print(m)
print(n)
