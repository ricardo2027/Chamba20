d=["Prpgramacion","Fisica","Calculo"]
h=d.copy()
del d[:]
print(d)
print(h)