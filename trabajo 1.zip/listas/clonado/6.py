n=["10","15","16"]
v=n.copy()
del n[1]
print(n)
print(v)