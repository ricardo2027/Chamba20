fruta1="Manzana"
fruta2="Uva"
a=[fruta1,fruta2]
g=a.copy()
del a[0]
print(a)
print(g)