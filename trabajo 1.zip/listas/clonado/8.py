x=["lista","set","tuplas"]
g=x.copy()
del x[1]
print(x)
print(g)