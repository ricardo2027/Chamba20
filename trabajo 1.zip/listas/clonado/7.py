p=["Rojo","Negro","Amarillo"]
x=p.copy()
del p[2]
print(p)
print(x)