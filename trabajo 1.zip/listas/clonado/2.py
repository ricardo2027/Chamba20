a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
x=a.copy()
del a[0]
print(x)
print(a)