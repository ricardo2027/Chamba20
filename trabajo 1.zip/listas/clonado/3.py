x=["Ricardo","Chamba",20]
f=x.copy()
del x[2]
print(x)
print(f)