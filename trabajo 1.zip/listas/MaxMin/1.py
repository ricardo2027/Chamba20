a=[1,2,3,19]
print(max(a))