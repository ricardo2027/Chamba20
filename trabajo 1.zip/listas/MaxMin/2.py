a=[1,2,3,-4,-1]
print(min(a))