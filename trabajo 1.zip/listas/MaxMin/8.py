n=[12,15,20-7]
print(max(n))