n=[12,15,20-9]
print(min(n))