l=["Manzana","manzana"]
print(min(l))