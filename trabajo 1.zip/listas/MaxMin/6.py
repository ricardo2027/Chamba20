l=["Manzana","manzana"]
print(max(l))