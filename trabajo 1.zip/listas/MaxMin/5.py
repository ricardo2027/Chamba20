a="12"
b="21"
c=12
v=[int(a+b),c]
print(max(v))