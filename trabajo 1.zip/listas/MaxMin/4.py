a=["Ricardo","Chamba"]
print(min(a))