x=["Fresa","15"]
print(max(x))