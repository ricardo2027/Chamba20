a=["Ricardo","Chamba"]
print(max(a))