f=["Fat","Lia","Mantha"]
for F in f:
    print(F)