t=["Universidad","Licenciada",":)"]
for S in t:
    print(S)