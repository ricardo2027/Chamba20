a=[12,15,17]
for c in a:
    print(c)