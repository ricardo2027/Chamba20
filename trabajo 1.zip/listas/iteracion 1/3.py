marcas=["Samsung","Apple","Motorola"]
for i in marcas:
    print(i)