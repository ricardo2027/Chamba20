g=["Perro","Gato","Chancho"]
for o in g:
    print(o)