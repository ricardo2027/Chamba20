programas=["Python","C++","Java"]
for item in programas:
    print(item)