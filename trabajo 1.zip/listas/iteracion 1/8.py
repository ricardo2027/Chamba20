k=["","PC","Android"]
for q in k:
    print(q)