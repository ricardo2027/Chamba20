p=["Ricardo","Chamba"]
for n in p:
    print(n)