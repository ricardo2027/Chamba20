fruta=["Manzana","Fresa","Pera"]
for item in fruta:
    print(item)