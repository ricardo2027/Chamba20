l=[9,1,1]
for b in l:
    print(l)