x=[19,15,9,8]
nota=12
if nota not in x:
    print("No hay un", nota, "en la lista")

else:
    print("Hay al menos un", nota, " en la lista")