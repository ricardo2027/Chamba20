x=["Ricardo","Chamba"]
apel="Chamba"
if apel in x:
    print("Tu apellido se encuentra en la lista")
else:
    print("Tu apellido no se encuentra en la lista")