tipo_de_sangre_de_los_alumnos=["AB+","O+","AB-"]
tipo_de_sangre="A-"
if tipo_de_sangre not in tipo_de_sangre_de_los_alumnos:
    print("No hay alguien que tenga sangre de tipo", tipo_de_sangre)
else:
    print("Alguien que tiene sangre de tipo", tipo_de_sangre)