Primer_apellido="Chamba"
Segundo_apellido="Jimenez"
Pre_nombres="Ricardo Martin"
Fecha_De_Nacimiento="20/03/2002"
x=[Pre_nombres,Primer_apellido,Segundo_apellido,Fecha_De_Nacimiento]
Apellido_2="Jimenez"
if (Apellido_2 not in x[3]):
    print("El segundo apellido no esta en la posicion 3")

else:
    print("El segundo apellido esta en la posicion 3")