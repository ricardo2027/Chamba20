x=[20,17,18,10]
nota=20
if nota in x:
    print("Hay al menos un",nota ," en la lista")
else:
    print("No hay un",nota ,"en la lista")