Lista_De_Dispositivos_Electronicos=["protoboard","arduino","fusible","resistor"]
dispositivo=input("Ingrese un dispositivo electronico: ")

if (dispositivo.lower() in Lista_De_Dispositivos_Electronicos):
    print("El nombre del dispositivo electronico ingresado esta en la Lista :)")
else:
    print("Dispositivo ingresado no esta en la lista :(")
