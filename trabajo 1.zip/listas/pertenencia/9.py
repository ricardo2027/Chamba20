tipo_de_sangre_de_los_alumnos=["A+","O-","B-"]
tipo_de_sangre="O-"
if tipo_de_sangre  in tipo_de_sangre_de_los_alumnos:
    print("Existe alguien que tiene sangre de tipo",tipo_de_sangre)
else:
    print("No hay alguien que tenga sangre de tipo", tipo_de_sangre)