notas=[12,10,13]
nota=16
if nota not in notas:
    print("No hay un", nota, "en la lista de notas")
else:
    print("Hay al menos un", nota, "en la lista de notas")