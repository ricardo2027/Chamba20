Lista_De_Generos_Musicales = ["ROCK","CUMBIA","ELECTRONICA","SALSA"]
genero_musical = input("Ingrese un genero musical: ")

if (genero_musical.upper() in Lista_De_Generos_Musicales):
    print("El nombre del genero musical ingresado esta en la Lista ")
else:
    print("Genero musical no esta en la lista ")
