s=[12,14]
x=s.pop(0)
print(s)
print(x)