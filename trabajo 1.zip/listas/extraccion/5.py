n=["10","15","16"]
x=n.pop(1)
print(n)
print(x)