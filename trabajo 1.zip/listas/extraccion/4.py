d=["Prpgramacion","Fisica","Calculo"]
x=d.pop()
print(d)
print(x)