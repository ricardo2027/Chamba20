m=["Samsung","Apple","Huawei"]
n=m.pop(1)
print(n)
print(m)
