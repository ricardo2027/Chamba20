p=["Rojo","Negro","Amarillo"]
q=p.pop(2)
print(q)
print(p)