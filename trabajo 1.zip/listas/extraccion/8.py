r=["Arduino","Raspberry","Pc"]
s=r.pop(2)
print(s)
print(r)