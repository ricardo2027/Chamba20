x=["lista","set","tuplas"]
y=x.pop(1)
print(y)
print(x)