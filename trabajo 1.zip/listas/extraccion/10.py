x=["Ricardo","Chamba",20]
y=x.pop(2)
print(y)
print(x)