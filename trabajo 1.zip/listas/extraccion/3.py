a=["Universidad","Pedro Ruiz Gallo"]
x=a.pop(1)
print(a)
print(x)