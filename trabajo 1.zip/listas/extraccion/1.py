s=[12,15,17]
x=s.pop(1)
print(s)
print(x)