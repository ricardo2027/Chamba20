str=["Quiero" ,"ser" , "hacker"]
print(str.index("hacker"))