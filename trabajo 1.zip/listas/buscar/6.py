cad=["Gongora" ,"odiaba","Quevedo"]
print(cad.index("Quevedo"))