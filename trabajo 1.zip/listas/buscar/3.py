cad=["niña","dueloe","afliccion"]
print(cad.index("afliccion"))