cad=["Unamuno","Bilao"]
x="Unamuno"
print(cad.index(x))