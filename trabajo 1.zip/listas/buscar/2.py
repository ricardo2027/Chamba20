cad=["gustas","callas", "estas","ausente"]
print(cad.index("ausente"))