str=["Bienvenido" ,"Ricardo"]
print(str.index("Bienvenido"))