cad=["musa", "Gustavo", "Becquer", "Julia", "Spin"]
print(cad.index("Julia"))