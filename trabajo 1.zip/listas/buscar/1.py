cad=["padre","medicina","peruana","Hipolito Unanue"]
print(cad.index("medicina"))