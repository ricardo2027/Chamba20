cad=["Electronica","carrera","futuro"]
print(cad.index("Electronica"))