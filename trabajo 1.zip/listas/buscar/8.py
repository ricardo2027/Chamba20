cad=["cielos", "tierra", "me sonrien"]
print(cad.index("me sonrien"))