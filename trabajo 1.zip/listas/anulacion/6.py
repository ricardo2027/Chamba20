n=["10","15","16"]
n.clear()
print(n)