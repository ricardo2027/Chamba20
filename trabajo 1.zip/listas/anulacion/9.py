r=["Arduino","Raspberry","Pc"]
r.clear()
print(r)