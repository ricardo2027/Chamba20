x=["Ricardo","Chamba",20]
x.clear()
print(x)