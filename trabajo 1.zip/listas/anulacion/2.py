a=["Universidad","Pedro Ruiz Gallo","Licenciada"]
a.clear()
print(a)