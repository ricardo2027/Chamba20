p=["Rojo","Negro","Amarillo"]
p.clear()
print(p)