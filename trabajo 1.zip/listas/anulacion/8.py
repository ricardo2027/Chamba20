x=["lista","set","tuplas"]
x.clear()
print(x)