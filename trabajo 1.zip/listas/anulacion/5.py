d=["Prpgramacion","Fisica","Calculo"]
d.clear()
print(d)