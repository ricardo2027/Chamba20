m=["Samsung","Apple","Huawei"]
m.clear()
print(m)
