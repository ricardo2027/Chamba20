s=[]
print(s)