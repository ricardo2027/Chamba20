x="Manzana"
y="Naranja"
z="Fresa"
a=[x,y,z]
print(a)