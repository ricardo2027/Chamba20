a="Ricardo"
d=[a,a]
print(d)
