a="Habia"
b="Una"
c="Vez"
d=[a+b+c,a]
print(d)