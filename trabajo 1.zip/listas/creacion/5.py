r="Arduino"
s="Protoboard"
v=[r,s]
print(v)