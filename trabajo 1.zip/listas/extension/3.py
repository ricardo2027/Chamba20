x=["Ricardo","Chamba"]
y=[20,17]
x.extend(y)
print(x)