a=["Universidad","Pedro Ruiz Gallo"]
b=["Licenciada",":)"]
a.extend(b)
print(a)