d=["Prpgramacion","Fisica","Calculo"]
e=["Analisis","Autocad"]
d.extend(e)
print(d)