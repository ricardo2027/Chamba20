n=["10","15","16"]
m=[12,20]
n.extend(m)
print(n)