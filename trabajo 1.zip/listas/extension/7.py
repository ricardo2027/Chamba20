p=["Rojo","Negro","Amarillo"]
v=["Blanco"," "]
p.extend(v)
print(p)