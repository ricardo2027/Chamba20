m=["Samsung","Apple","Huawei"]
n=["MiU","Motorola"]
m.extend(n)
print(m)
