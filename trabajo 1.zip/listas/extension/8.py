x=["lista","set","tuplas"]
y=["if","while"]
x.extend(y)
print(x)