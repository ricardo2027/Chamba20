s=[12,14]
f=[11,10]
s.extend(f)
print(s)