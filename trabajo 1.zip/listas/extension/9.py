r=["Arduino","Raspberry","Pc"]
s=["Android","Apple"]
r.extend(s)
print(r)