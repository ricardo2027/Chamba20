fruta1="Manzana"
fruta2="Uva"
a=[fruta1,fruta2]
b=["Pera"]
a.extend(b)
print(a)