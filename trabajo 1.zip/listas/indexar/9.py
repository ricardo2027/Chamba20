c="15"
d="29"
e=[c,d+c]
print(e[1])