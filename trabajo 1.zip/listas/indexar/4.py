nota1="10"
nota2="15"
a=[nota1,nota2]
x=a[1]
print(x)