d=["Pera","Fisica","Pesca"]
print(d[2])