nombre1=input("Ingrese su nombre")
nro_dni=int(input("Ingrese su nro de DNI: "))
x=[nombre1,nro_dni]
a=x[1]
print(a)