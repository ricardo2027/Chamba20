a=[12,1,2]
print(a[0])