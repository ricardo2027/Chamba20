nota1=15
nota2=18
a=[nota1,nota2]
x=a[0]
print(x)