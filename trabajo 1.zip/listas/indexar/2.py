curso1="Programacion II"
curso2="Analisis II"
a=[curso1,curso2]
x=a[0]
print(x)