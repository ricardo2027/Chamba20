d=[12,"PG2","Yeso"]
print(d[2])